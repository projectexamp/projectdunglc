create or replace PACKAGE               "PCK_CIS_REQUEST" AS
  /* DoNB 26/03/2019 */
  /* TODO enter package declarations (types, exceptions, methods etc) here */ 

    PROCEDURE PR_CREATE_CIS_REQUEST (
        p_id CIS_REQUEST.ID%TYPE,
        p_cis_no CIS_REQUEST.CIS_NO%TYPE,
        p_channel CIS_REQUEST.CHANNEL%TYPE,
        p_customer_type CIS_REQUEST.CUSTOMER_TYPE%TYPE,
        p_status CIS_REQUEST.STATUS%TYPE,
        p_product_code CIS_REQUEST.PRODUCT_CODE%TYPE,
        p_member_code CIS_REQUEST.MEMBER_CODE%TYPE,
        p_cic_code CIS_REQUEST.CIC_CODE%TYPE,
        p_id_no CIS_REQUEST.ID_NO%TYPE,
        p_tax_code CIS_REQUEST.TAX_CODE%TYPE,
        p_username_request CIS_REQUEST.USERNAME_REQUEST%TYPE,
        p_branch_code CIS_REQUEST.BRANCH_CODE%TYPE,
        p_created_date CIS_REQUEST.CREATED_DATE%TYPE,
        p_requested_date CIS_REQUEST.REQUESTED_DATE%TYPE,
        p_request_data CIS_REQUEST.REQUEST_DATA%TYPE,
        p_err_code CIS_REQUEST.ERR_CODE%TYPE,
        p_err_msg CIS_REQUEST.ERR_MSG%TYPE,
        p_address CIS_REQUEST.ADDRESS%TYPE,
        p_register_no CIS_REQUEST.REGISTER_NO%TYPE,
        p_note CIS_REQUEST.NOTE%TYPE,
        p_customer_name CIS_REQUEST.CUSTOMER_NAME%TYPE,
        p_customer_code CIS_REQUEST.CUSTOMER_CODE%TYPE,
        p_response_date CIS_REQUEST.RESPONSE_DATE%TYPE,
        p_email CIS_REQUEST.EMAIL%TYPE,
        p_last_version CIS_REQUEST.LAST_VERSION%TYPE,
        p_flag CIS_REQUEST.FLAG%TYPE,
        p_msg_id CIS_REQUEST.MSG_ID%TYPE,
        p_application_id CIS_REQUEST.APPLICATION_ID%TYPE,
        p_maker CIS_REQUEST.MAKER%TYPE,
        p_task_id CIS_REQUEST.TASK_ID%TYPE,
        p_encode_request cis_request.encode_request%TYPE,
        p_borrower CIS_REQUEST.BORROWER%TYPE,
        p_pcb_code CIS_REQUEST.PCB_CODE%TYPE,
        p_ccy CIS_REQUEST.CCY%TYPE,
        p_amount_fin_capital CIS_REQUEST.AMOUNT_FIN_CAPITAL%TYPE,
        p_total_instalment CIS_REQUEST.TOTAL_INSTALMENT%TYPE,
        p_credit_limit CIS_REQUEST.CREDIT_LIMIT%TYPE,
        p_gender CIS_REQUEST.GENDER%TYPE,
        p_dob CIS_REQUEST.DOB%TYPE,
        p_doc_type CIS_REQUEST.DOC_TYPE%TYPE,
        p_pay_periodicity CIS_REQUEST.PAY_PERIODICITY%TYPE,
        p_operation_type CIS_REQUEST.OPERATION_TYPE%TYPE,
        p_country_of_birth CIS_REQUEST.COUNTRY_OF_BIRTH%TYPE,
        p_request_id CIS_REQUEST.REQUEST_ID%TYPE,
        p_frequent_contacts CIS_REQUEST.FREQUENT_CONTACTS%TYPE,
        p_phone_number CIS_REQUEST.PHONE_NUMBER%TYPE,
        p_user varchar2,
        p_client_ip varchar2,
        p_user_agent varchar2,
        p_nam_tai_chinh varchar2,
        p_out    OUT SYS_REFCURSOR);

    PROCEDURE PR_UPDATE_STATUS_CIS_REQUEST (
        p_cis_no CIS_REQUEST.CIS_NO%TYPE,
        p_status CIS_REQUEST.STATUS%TYPE,
        p_request_data CIS_REQUEST.REQUEST_DATA%TYPE,
        p_msg_id CIS_REQUEST.MSG_ID%TYPE,
        p_err_code CIS_REQUEST.ERR_CODE%TYPE,
        p_err_msg CIS_REQUEST.ERR_MSG%TYPE,
        p_out    OUT SYS_REFCURSOR);

    PROCEDURE PR_GET_LIST_CIS_REQUEST (
        p_id_no CIS_REQUEST.ID_NO%TYPE,
        p_member_code CIS_REQUEST.MEMBER_CODE%TYPE,
        p_register_no CIS_REQUEST.REGISTER_NO%TYPE,
        p_customer_name CIS_REQUEST.CUSTOMER_NAME%TYPE,
        p_tax_code CIS_REQUEST.TAX_CODE%TYPE,
        p_address CIS_REQUEST.ADDRESS%TYPE,
        p_customer_type CIS_REQUEST.CUSTOMER_TYPE%TYPE,
        p_cic_code CIS_REQUEST.CIC_CODE%TYPE,
        p_customer_code CIS_REQUEST.CUSTOMER_CODE%TYPE,
        p_product_code CIS_REQUEST.PRODUCT_CODE%TYPE,
        p_cis_no CIS_REQUEST.CIS_NO%TYPE,
        p_maker CIS_REQUEST.MAKER%TYPE,
        p_from_date CIS_REQUEST.REQUESTED_DATE%TYPE,
        p_to_date CIS_REQUEST.REQUESTED_DATE%TYPE,
        p_task_id CIS_REQUEST.TASK_ID%TYPE,
        p_status CIS_REQUEST.STATUS%TYPE,
        p_channel CIS_REQUEST.CHANNEL%TYPE,
        p_user varchar2,
        p_out    OUT SYS_REFCURSOR);

    PROCEDURE PR_GET_CIS_REQUEST_INFO (
        p_cis_no CIS_REQUEST.ID_NO%TYPE,
        p_out    OUT SYS_REFCURSOR);

    PROCEDURE PR_CHECK_REQUEST_INFO ( p_param1 varchar2,
                                      p_param2 varchar2,
                                      p_param3 varchar2,
                                      p_param4 varchar2,
                                      p_param5 varchar2,
                                      p_param6 varchar2,
                                      p_param7 varchar2,
                                      p_param8 varchar2,
                                      p_channel varchar2,
                                      p_user varchar2,
                                      p_client_ip varchar2,
                                      p_user_agent varchar2,
                                      p_out    OUT SYS_REFCURSOR);

    PROCEDURE PR_CHECK_BATCH_REQUEST_INFO (p_param1 varchar2,
                                        p_param2 varchar2,
                                        p_param3 varchar2,
                                        p_param4 varchar2,
                                        p_param5 varchar2,
                                        p_param6 varchar2,
                                        p_param7 varchar2,
                                        p_param8 varchar2,
                                        p_channel varchar2,
                                        p_user varchar2,
                                        p_client_ip varchar2,
                                        p_user_agent varchar2,
                                        p_out    OUT SYS_REFCURSOR);

    PROCEDURE PR_GET_LOT_NO (
        p_user                         IN     VARCHAR2,
        p_client_ip                    IN     VARCHAR2,
        p_user_agent                   IN     VARCHAR2,
        p_out    OUT SYS_REFCURSOR);

   FUNCTION PR_STATUS_MATRIX_PCB( p_product_code  varchar2,
                                      p_id_no  varchar2,
                                      p_doc_type  varchar2,
                                      P_register_no varchar2 ) RETURN VARCHAR2;

   FUNCTION PR_STATUS_MATRIX_CIC(p_id_no CIS_REQUEST.ID_NO%TYPE,
                              p_register_no CIS_REQUEST.REGISTER_NO%TYPE,
                              p_tax_code CIS_REQUEST.TAX_CODE%TYPE,
                              p_customer_type CIS_REQUEST.CUSTOMER_TYPE%TYPE,
                              p_product_code CIS_REQUEST.PRODUCT_CODE%TYPE,
                              p_cic_code varchar2) RETURN VARCHAR2;

   FUNCTION PR_STATUS_MATRIX_TS ( p_phone_number varchar2,
                                      p_product_code varchar2,
                                      p_id_no varchar2) RETURN VARCHAR2;

   FUNCTION PR_CHECK_BLACK_LIST ( p_id_no varchar2) RETURN VARCHAR2;

   PROCEDURE PR_ADD_CIS_REQUEST_EMAIL (
        P_CIS_NO CIS_REQUEST.CIS_NO%TYPE,
        P_USER                         IN     VARCHAR2,
        P_CLIENT_IP                    IN     VARCHAR2,
        P_USER_AGENT                   IN     VARCHAR2,
        P_OUT    OUT SYS_REFCURSOR);

   PROCEDURE PR_GET_LIST_CIS_SENT (
        P_STATUS VARCHAR2,
        P_CHANNEL                         IN     VARCHAR2,
        P_USER                    IN     VARCHAR2,
        P_OUT    OUT SYS_REFCURSOR);

   --FIX Loi SENDDING - 7/4/2021
   PROCEDURE PR_GET_LIST_CIS_NEW (
        P_STATUS VARCHAR2,
        P_CHANNEL                         IN     VARCHAR2,
        P_USER                    IN     VARCHAR2,
        P_OUT    OUT SYS_REFCURSOR);

   PROCEDURE PR_AUTO_REJECT_REQUEST;

END PCK_CIS_REQUEST;

