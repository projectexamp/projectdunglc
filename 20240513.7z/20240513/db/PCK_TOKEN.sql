--PCK
create or replace PACKAGE               "PCK_TOKEN" AS 

PROCEDURE PR_GET_TOKEN (p_out    OUT SYS_REFCURSOR);

END PCK_TOKEN;







-- BODY
create or replace PACKAGE BODY               "PCK_TOKEN" AS

  PROCEDURE PR_GET_TOKEN (p_out    OUT SYS_REFCURSOR) AS
  BEGIN
    -- TODO: Implementation required for PROCEDURE PCK_TOKEN.PR_GET_TOKEN
    OPEN P_OUT FOR
    SELECT * FROM SYS_TOKEN;

  END PR_GET_TOKEN;
END PCK_TOKEN;


